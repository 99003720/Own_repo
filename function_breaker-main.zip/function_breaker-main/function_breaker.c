#include <stdio.h>
#include <string.h>
void Function_breaker(char *arr)
{
int dollar=0,semi=0;
for(int i=0;i<strlen(arr);i++)
{
if(arr[i]=='$')
{
dollar=i;
}
else if(arr[i] == ';')
{
semi = i;
}
}
for(int i=dollar;i<=semi;i++)
{
printf("%c",arr[i]);
}
}
int main()
{
FILE *fptr;
fptr = fopen("test_file.txt","rt");
char arr[100];
while (fgets(arr,100,fptr))
{
	Function_breaker(arr);
}
return 0;
}
